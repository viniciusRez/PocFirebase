open class Animal() {
    open fun comunicar() {
        println("E um animal")
    }

}
class Gato:Animal() {
    fun miar() {
        println("Miau Miau")

    }
    override fun comunicar() {
        miar()
    }
}
class Cachorro:Animal() {
    fun latir() {
        println("Au Au!!")

    }
    override fun comunicar() {
        latir()
    }
}