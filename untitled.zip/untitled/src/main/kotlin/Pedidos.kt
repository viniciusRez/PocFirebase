/* https://www.youtube.com/watch?v=QDsRjpNGqXI
*   Enum class e um tipo de classe para armazenamento de conjunto de constantes
* valores imutaveis
*/
enum class StatusPedidos{
    PROCESSANDO,APROVADO,REPROVADO
}

class Pedidos {
    var status:StatusPedidos
    init {
           this.status = StatusPedidos.PROCESSANDO
       }
    fun checkStatus(){
        if (status == StatusPedidos.PROCESSANDO) {
            println("Pedido em Analise")
        } else if (status == StatusPedidos.APROVADO) {
            println("Pedido Aprovado")
        } else {
            println("Pedido Reprovado")
        }
    }

}