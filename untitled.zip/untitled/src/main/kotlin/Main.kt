import java.util.*

/*https://www.youtube.com/watch?v=PMwiMNeFSM0*/
sealed class Vehicle(val qtdWheels: Int, val name: String, val velocity: Int) {

    fun stop(distance: Int) {
        val distanceForStop: Int = distance / velocity
        println("The distance for stop of $name is this $distanceForStop meters.")
    }

    fun running(time: Int) {
        val distance: Int = velocity * time
        println("The distance traveled will be $distance Km")
    }


}

class Car(qtdWheels: Int, name: String, velocity: Int) : Vehicle(qtdWheels, name, velocity) {

    private fun playMusic(estacao: Double, volume: Int) {
        println("radio is on station $estacao in the volume: $volume %")
    }

    fun allFunction(distancia: Int, tempo: Int, estacao: Double, volume: Int) {
        running(tempo)
        playMusic(estacao, volume)
        stop(distancia)

    }
}

/* sealed class
* compile time
* more control over inheritance
*
*/
class Motorcycle(qtdWheels: Int, name: String, velocity: Int) : Vehicle(qtdWheels, name, velocity) {
    fun travel(local: String, time: Int) {
        running(local)
        running(time)

    }
}

private fun detail(v: Vehicle): String {
    return when (v) {
        is Car -> {
            "Name ${v.name}; Velocity:${v.velocity}; Quantity of wheels: ${v.qtdWheels}"
        }

        is Motorcycle -> {
            "Name ${v.name}; Velocity:${v.velocity}; Quantity of wheels: ${v.qtdWheels}; fall risk"
        }
    }
}

/* mantenho o retorno como String mesmo ele vazio, consigo alterar o comportamento comum do termo */
fun Any?.toString(): String {
    if (this == null) {
        return "this is null"
    }
    return toString()
}

/* Extension for Vehicle */
fun running(place: String) {
    println("The destination place is  $place")
}

fun main(args: Array<String>) {
    do{
        print("1_ Cadastro de Veiculos 2_ Enum class 3_ Sair: ")
        val action = readln().toInt()
        if(action == 3 ){
            break
        }
        when(action){
            1 -> cadastroCarros()
            2 -> enumTester()
        }
    }while (action < 3)
}
fun enumTester(){
    println("Enum tester")
    val pedidos = Pedidos()
    val random = (0..10).random()
    var x = 0
    do {
        x++
        if ((x % 2) === 0) {
            pedidos.status = StatusPedidos.APROVADO
        } else {
            pedidos.status = StatusPedidos.REPROVADO
        }

    } while (x < random)
    println(pedidos.checkStatus())
}
fun cadastroCarros(){
    val dono = Dono()
    do {
        print("Você gostaria de cadastrar um carro ou uma moto: ")
        val action = readln()
        val qtdWheels:Int
        if(action.lowercase(Locale.getDefault()) == "parar"){
            break
        }
        println("You entered: $action")
        print("Nome do Veiculo: ")
        val carName: String = readln()
        print("Velocidade Maxima: ")
        val carVelocity: Int = readln().toInt()
        if (action == "Carro") {
            qtdWheels = 4
            val newVehicle = Car(qtdWheels, carName, carVelocity)
            dono.addSquad(newVehicle)
        } else if (action.lowercase(Locale.getDefault()) == "moto") {
            qtdWheels = 2
            val newVehicle = Motorcycle(qtdWheels, carName, carVelocity)
            dono.addSquad(newVehicle)
        }

    } while (action.lowercase(Locale.getDefault()) != "parar")
    dono.vehicleList.forEach { v ->
        println("Name ${v.name}; Velocity:${v.velocity}; Quantity of wheels: ${v.qtdWheels}" )
    }
}
private fun Animals(a: Animal): Any {
    return when (a) {
        is Cachorro -> {
            a.comunicar()
        }

        is Gato -> {
            a.comunicar()
        }

        else -> {
            a.comunicar()
        }
    }
}