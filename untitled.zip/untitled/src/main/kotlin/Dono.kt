class Dono(val vehicleList: MutableList<Vehicle> = mutableListOf()) {
    fun addSquad(newVehicle: Vehicle): Boolean {
        val exists =
            vehicleList.find { vehicleList -> vehicleList.name == newVehicle.name /*|| squad.lider == infoSquad.lider*/ }
        return if (exists == null) {
            vehicleList.add(newVehicle)
            true
        } else {
            false
        }
    }
}

/*    val number: Int? = null
    val numberText: String = number.toString()
    println(numberText)
    println(" ")
    val captur = Car(4, "Captur", 120)
    captur.allFunction(1200, 10, 88.7, 90)

    println(" ")
    val harley = Motorcycle(2, "Harley", 200)
    harley.travel("New York", 10)

    println(detail(captur))
    println(detail(harley))
    println("Program arguments: ${args.joinToString()}")

    println("Enum tester")
    val pedidos = Pedidos()
    val random = (0..10).random()
    var x = 0
    do {
        x++
        if ((x % 2) === 0) {
            pedidos.status = StatusPedidos.APROVADO
        } else {
            pedidos.status = StatusPedidos.REPROVADO
        }

    } while (x < random)
//    println(pedidos.pagar(1200.90,"Dinheiro"))
    println(pedidos.checkStatus())
    println(" ")

    val cachorro = Cachorro()
    val animal =Animal()
    val gato = Gato()
    Animals(cachorro)
    Animals(animal)
    Animals(gato)*/
